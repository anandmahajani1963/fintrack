// ============================================================
// fintrack mobile — API client
// File: src/api/client.js
// Version: 1.0 — 2026-04-20
// ============================================================

import axios from 'axios'

export const API_BASE = 'https://192.168.1.170:32606'

const api = axios.create({
  baseURL: API_BASE,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
})

export function setAuthHeaders(token, password) {
  api.defaults.headers.common['Authorization'] = `Bearer ${token}`
  if (password) {
    api.defaults.headers.common['X-Fintrack-Password'] = password
  }
}

export function clearAuthHeaders() {
  delete api.defaults.headers.common['Authorization']
  delete api.defaults.headers.common['X-Fintrack-Password']
}

export const auth = {
  login: (email, password) =>
    api.post('/api/v1/auth/login', { email, password }),

  refresh: (refresh_token) =>
    api.post('/api/v1/auth/refresh', { refresh_token }),

  mfaChallenge: (code, token) =>
    api.post('/api/v1/mfa/challenge', { code },
      { headers: { Authorization: `Bearer ${token}` } }),

  sendLoginOTP: (token) =>
    api.post('/api/v1/mfa/send-login-otp', {},
      { headers: { Authorization: `Bearer ${token}` } }),
}

export const analytics = {
  categorySummary: (year) =>
    api.get(`/api/v1/analytics/category-summary?year=${year}`),

  monthlyTrend: (year) =>
    api.get(`/api/v1/analytics/trend?year=${year}`),

  budgetStatus: (year) =>
    api.get(`/api/v1/budget/status?year=${year}`),
}

export const transactions = {
  list: (params) =>
    api.get('/api/v1/transactions', { params }),
}

export default api
