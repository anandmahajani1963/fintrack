// ============================================================
// fintrack — Auth context
// File: src/context/AuthContext.jsx
// Version: 1.2 — 2026-03-31
// Changes:
//   v1.0  2026-03-26  Initial implementation
//   v1.1  2026-03-30  Session restore on page refresh
//   v1.2  2026-03-31  Handle "session restored but no password" state
//                     Pages show password prompt instead of spinning forever
// ============================================================

import React, {
  createContext, useContext, useState,
  useCallback, useEffect
} from 'react'
import { auth } from '../api/client'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser]           = useState(null)
  const [password, setPassword]   = useState('')
  const [restoring, setRestoring] = useState(true)
  // True when session was restored but password not available
  const [needsPassword, setNeedsPassword] = useState(false)

  useEffect(() => {
    auth.tryRestoreSession().then(restored => {
      if (restored) {
        setUser({ email: auth.email() })
        setNeedsPassword(true)  // session ok, but password needs re-entry
      }
      setRestoring(false)
    })
  }, [])

  const login = useCallback(async (email, pwd) => {
    const data = await auth.login(email, pwd)
    setUser({ id: data.user_id, email: data.email })
    setPassword(pwd)
    setNeedsPassword(false)
    return data
  }, [])

  const supplyPassword = useCallback((pwd) => {
    setPassword(pwd)
    setNeedsPassword(false)
  }, [])

  const logout = useCallback(() => {
    auth.logout()
    setUser(null)
    setPassword('')
    setNeedsPassword(false)
  }, [])

  if (restoring) {
    return (
      <div className="min-h-screen flex items-center justify-center
                      bg-gray-50 dark:bg-gray-900">
        <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600
                        rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <AuthContext.Provider value={{
      user, password, login, logout,
      isLoggedIn: !!user,
      needsPassword, supplyPassword
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
