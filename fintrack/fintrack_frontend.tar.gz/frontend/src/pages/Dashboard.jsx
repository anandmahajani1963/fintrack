// ============================================================
// fintrack — Dashboard page
// File: src/pages/Dashboard.jsx
// Version: 1.0 — 2026-03-26
// ============================================================

import React, { useEffect, useState } from 'react'
import {
  LineChart, Line, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid
} from 'recharts'
import { useAuth }    from '../context/AuthContext'
import { analytics }  from '../api/client'
import { Card, StatCard, Loading, ErrorMsg, SectionTitle, fmt } from '../components/ui'
import { TrendingUp, TrendingDown, Minus } from 'lucide-react'

export default function Dashboard({ year }) {
  const { password }  = useAuth()
  const [data, setData]   = useState(null)
  const [trend, setTrend] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    setData(null); setError('')
    Promise.all([
      analytics.categorySummary(year),
      analytics.trend(year),
    ])
      .then(([cat, tr]) => { setData(cat); setTrend(tr) })
      .catch(e => setError(e.message))
  }, [year])

  if (error) return <ErrorMsg message={error} />
  if (!data || !trend) return <Loading />

  const months = trend.months
  const lastMonth  = months[months.length - 1]
  const prevMonth  = months[months.length - 2]
  const momDelta   = lastMonth?.mom_delta || 0
  const MomIcon    = momDelta > 0 ? TrendingUp : momDelta < 0 ? TrendingDown : Minus
  const momColor   = momDelta > 0 ? 'text-red-500' : 'text-green-500'

  // Top 5 categories by spend (excluding Other)
  const topCats = data.categories
    .filter(c => c.category !== 'Other')
    .slice(0, 5)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
          Financial overview — {year}
        </p>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Total Spend"
          value={fmt(data.grand_total)}
          sub={`${data.categories.length} categories`}
          color="blue"
        />
        <StatCard
          label="Essential"
          value={fmt(data.essential_total)}
          sub={`${data.essential_pct}% of total`}
          color="green"
        />
        <StatCard
          label="Non-Essential"
          value={fmt(data.nonessential_total)}
          sub={`${data.nonessential_pct}% of total`}
          color="amber"
        />
        <StatCard
          label={`${lastMonth?.month || 'Last month'}`}
          value={fmt(lastMonth?.total || 0)}
          sub={
            <span className={`flex items-center gap-1 ${momColor}`}>
              <MomIcon size={12} />
              {momDelta >= 0 ? '+' : ''}{fmt(momDelta)} vs prior month
            </span>
          }
          color={momDelta > 0 ? 'red' : 'green'}
        />
      </div>

      {/* Trend chart */}
      <Card>
        <SectionTitle>Monthly Spending — {year}</SectionTitle>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={months} margin={{ top: 5, right: 10, bottom: 5, left: 10 }}>
            <CartesianGrid strokeDasharray="3 3"
                           stroke="rgba(156,163,175,0.3)" />
            <XAxis
              dataKey="month"
              tick={{ fontSize: 11 }}
              tickFormatter={m => m.split(' ')[0]}
            />
            <YAxis
              tick={{ fontSize: 11 }}
              tickFormatter={v => `$${(v/1000).toFixed(0)}k`}
              width={45}
            />
            <Tooltip
              formatter={(v) => [fmt(v), 'Spend']}
              contentStyle={{
                fontSize: 12,
                borderRadius: 8,
                border: '1px solid rgba(156,163,175,0.3)',
              }}
            />
            <Line
              type="monotone"
              dataKey="total"
              stroke="#2563eb"
              strokeWidth={2}
              dot={{ r: 3, fill: '#2563eb' }}
              activeDot={{ r: 5 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      {/* Top categories */}
      <Card>
        <SectionTitle>Top Categories</SectionTitle>
        <div className="space-y-3">
          {topCats.map(cat => {
            const pct = cat.pct
            return (
              <div key={`${cat.category}-${cat.subcategory}`}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-700 dark:text-gray-300 font-medium">
                    {cat.category}
                    {cat.category !== cat.subcategory &&
                      <span className="text-gray-400 font-normal"> / {cat.subcategory}</span>
                    }
                  </span>
                  <span className="text-gray-900 dark:text-white font-semibold">
                    {fmt(cat.total)}
                    <span className="text-gray-400 font-normal ml-1">({pct}%)</span>
                  </span>
                </div>
                <div className="h-1.5 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width:      `${Math.min(pct * 2, 100)}%`,
                      background: cat.color_code || '#3b82f6'
                    }}
                  />
                </div>
              </div>
            )
          })}
        </div>
      </Card>
    </div>
  )
}
